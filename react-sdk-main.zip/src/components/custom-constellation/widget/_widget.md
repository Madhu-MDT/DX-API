# The **custom-constellation/widget** directory

The **src/components/custom-constellation/widget** directory contains the code for the Constellation-based associated component for any custom **widget** component you have created for use with the **React SDK**.

For each component in the **src/components/custom-constellation/widget** directory, there will be a matching component in the **src/components/custom-sdk/widget** directory.
