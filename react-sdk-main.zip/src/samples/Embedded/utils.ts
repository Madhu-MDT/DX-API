import { sdkSetAuthHeader, sdkSetCustomTokenParamsCB } from '@pega/auth/lib/sdk-auth-manager';

export const shoppingOptions = [
  {
    play: 'We are hiring',
    level: 'Pega Developers',
    channels: '12+',
    channels_full: 'Technical Skills: Pega,HTML,CSS,JavaScript',
    channelsfull2: 'UI/UX: Responsive, user-friendly designs.',
    channelsfull3: 'Problem-Solving: debugging & optimization.',
    banner: 'Actively Looking for Pega Developers',
    price: '5-12.00',
    internetSpeed: 'Teamwork: Collaboration & communication.',
    calling: 'Experience: Portfolio or past projects.'
  },
  {
    play: 'We are hiring',
    level: 'Salesforce CRM',
    channels: '10+',
    channels_full: 'Technical Skills: Apex, LWC, SOQL, APIs',
    channelsfull2: 'CRM Expertise: Automation & integrations.',
    channelsfull3: 'Problem-Solving: debugging & optimization.',
    banner: 'Actively Looking for Sales Professionals',
    price: '6-12.00',
    internetSpeed: 'Teamwork: Collaboration & communication.',
    calling: 'Experience: Certifications (e.g., PD1).'
  },
  {
    play: 'We are hiring',
    level: 'Test Automation',
    channels: '5+',
    channels_full: 'Tech Skills: Selenium, Appium, Java/Python.',
    channelsfull2: 'Automation: CI/CD, frameworks, scripting.',
    channelsfull3: 'Problem-Solving: debugging & optimization.',
    banner: 'Actively Looking for Automation Professionals',
    price: '4-8.00',
    internetSpeed: 'Teamwork: Collaboration & communication.',
    calling: 'Experience: Test strategies, past projects.'
  }
];

export function initializeAuthentication(sdkConfigAuth) {
  if ((sdkConfigAuth.mashupGrantType === 'none' || !sdkConfigAuth.mashupClientId) && sdkConfigAuth.customAuthType === 'Basic') {
    // Service package to use custom auth with Basic
    const sB64 = window.btoa(`${sdkConfigAuth.mashupUserIdentifier}:${window.atob(sdkConfigAuth.mashupPassword)}`);
    sdkSetAuthHeader(`Basic ${sB64}`);
  }

  if ((sdkConfigAuth.mashupGrantType === 'none' || !sdkConfigAuth.mashupClientId) && sdkConfigAuth.customAuthType === 'BasicTO') {
    const now = new Date();
    const expTime = new Date(now.getTime() + 5 * 60 * 1000);
    let sISOTime = `${expTime.toISOString().split('.')[0]}Z`;
    const regex = /[-:]/g;
    sISOTime = sISOTime.replace(regex, '');
    // Service package to use custom auth with Basic
    const sB64 = window.btoa(`${sdkConfigAuth.mashupUserIdentifier}:${window.atob(sdkConfigAuth.mashupPassword)}:${sISOTime}`);
    sdkSetAuthHeader(`Basic ${sB64}`);
  }

  if (sdkConfigAuth.mashupGrantType === 'customBearer' && sdkConfigAuth.customAuthType === 'CustomIdentifier') {
    // Use custom bearer with specific custom parameter to set the desired operator via
    //  a userIdentifier property.  (Caution: highly insecure...being used for simple demonstration)
    sdkSetCustomTokenParamsCB(() => {
      return { userIdentifier: sdkConfigAuth.mashupUserIdentifier };
    });
  }
}
