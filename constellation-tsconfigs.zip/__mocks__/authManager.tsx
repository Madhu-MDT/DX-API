/** This file contains the Mocks for the various auth-manager APIs */
export function getHomeUrl() {
  /* nothing */
}
export function authIsMainRedirect() {
  /* nothing */
}
export function authRedirectCallback() {
  /* nothing */
}
export function sdkIsLoggedIn() {
  /* nothing */
}
export function loginIfNecessary() {
  /* nothing */
}
export function sdkSetAuthHeader() {
  /* nothing */
}
export function sdkSetCustomTokenParamsCB() {
  /* nothing */
}
export function getSdkConfig() {
  /* nothing */
}
export function SdkConfigAccess() {
  /* nothing */
}
export function getAvailablePortals() {
  /* nothing */
}
export function logout() {
  /* nothing */
}
