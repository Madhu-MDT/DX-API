# The **tests/unit/components** directory

The **tests/unit/components** directory can be used for your component unit tests (ex: Jest).
