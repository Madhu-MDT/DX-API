console.log('\x1b[33m%s\x1b[0m', 'Running in headless mode, use `npm run test:headed` for running in headed mode.');
