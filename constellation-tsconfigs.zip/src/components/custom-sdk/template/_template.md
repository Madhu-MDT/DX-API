# The **custom-sdk/template** directory

The **src/components/custom-sdk/template** directory contains the code for the custom **template** components you want to create and use with the **React SDK**.

When you run the **npm run  create** command to create new _template_ components, the generated code that you can use as a starting point for your component development
will be placed in component-specific folders in **src/components/custom-sdk/template**.
