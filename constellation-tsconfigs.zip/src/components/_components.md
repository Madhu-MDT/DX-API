# The **components** directory

The **src/components** directory contains the code for the components you want to use with the **React SDK**.

When you run the **npm run  create** or **npm run override** commands to create new components, the generated code that
you can use as a starting point for your component development will be placed in component-specific folders inside **src/components**.
