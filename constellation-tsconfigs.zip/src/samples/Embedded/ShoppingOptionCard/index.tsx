/* eslint-disable react/button-has-type */
import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles(theme => ({
  swatchHeader: {
    display: 'flex',
    flexDirection: 'row',
    backgroundColor: '#7097e0',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 1)'
  },
  swatchPackage: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-around',
    width: '260px',
    height: '70px',
    backgroundColor: '#7097e0',
    padding: '5px'
  },
  swatchPlay: {
    letterSpacing: 'normal',
    color: 'white',
    fontSize: '25px'
  },
  swatchLevel: {
    letterSpacing: 'normal',
    color: 'white',
    fontSize: '28px',
    fontWeight: 'bold'
  },
  swatchChannels: {
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-evenly',
    letterSpacing: 'normal',
    alignItems: 'center',
    backgroundColor: theme.palette.primary.main,
    width: '100px'
  },
  swatchCount: {
    letterSpacing: 'normal',
    color: 'white',
    fontSize: '40px',
    fontWeight: 'bold'
  },
  swatchLabel: {
    letterSpacing: 'normal',
    color: 'white',
    fontSize: '17px'
  },
  swatchBody: {
    letterSpacing: 'normal',
    border: '1px solid lightgray',
    backgroundColor: '#ffffff',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    paddingBottom: '20px',
    borderRadius: '0px 0px 15px 15px',
    boxShadow: '0px 4px 4px rgba(107, 105, 105, 0.274)'
  },
  swatchBanner: {
    letterSpacing: 'normal',
    fontWeight: 'bold',
    fontSize: '15px',
    padding: '5px'
  },
  swatchPrice: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center'
  },
  swatchFromGroup: {
    height: '90px'
  },
  swatchFrom: {
    color: theme.palette.primary.main,
    textAlign: 'right'
  },
  swatchCurrency: {
    letterSpacing: 'normal',
    color: theme.palette.primary.main,
    fontSize: '30px',
    fontWeight: 'bold',
    fontFamily: 'Tahoma'
  },
  swatchDollars: {
    letterSpacing: 'normal',
    color: theme.palette.primary.main,
    fontSize: '90px',
    fontWeight: 'bold',
    fontFamily: 'Tahoma'
  },
  swatchCents: {
    letterSpacing: 'normal',
    color: theme.palette.primary.main,
    fontSize: '20px',
    fontWeight: 'bold',
    fontFamily: 'Tahoma'
  },
  swatchMonthly: {
    display: 'flex',
    flexDirection: 'column'
  },
  swatchShopButton: {
    color: 'white',
    backgroundColor: theme.palette.warning.main,
    fontSize: '25px',
    fontWeight: 'bold',
    borderRadius: '25px',
    border: '0px',
    margin: '20px',
    padding: '10px 30px'
  }
}));

export default function ShoppingOptionCard(props) {
  const classes = useStyles();

  const { play, level, channels, channels_full: channelsFull, channelsfull2, channelsfull3, banner, price, internetSpeed, calling } = props;

  return (
    <div>
      <div className={classes.swatchHeader}>
        <div className={classes.swatchPackage}>
          <div className={classes.swatchPlay}>{play}</div>
          <div className={classes.swatchLevel}>{level}</div>
        </div>
        <div className={classes.swatchChannels}>
          <div className={classes.swatchCount}>{channels}</div>
          <div className={classes.swatchLabel}>Positions</div>
        </div>
      </div>
      <div className={classes.swatchBody}>
        <div className={classes.swatchBanner}>{banner}</div>
        <ul>
          <li>{channelsFull}</li>
          <li>{channelsfull2}</li>
          <li>{channelsfull3}</li>
          <li>{internetSpeed}</li>
          <li>{calling}</li>
        </ul>

        <div className={classes.swatchPrice}>
          <div className={classes.swatchFromGroup}>
            <div className={classes.swatchFrom}>From</div>
          </div>

          <div className={classes.swatchDollars}>{price.substring(0, price.indexOf('.'))}</div>
          <div className={classes.swatchMonthly}>
            <div className={classes.swatchCents}>{price.substring(price.indexOf('.') + 1)}</div>
            <div>Years of </div>
            <div>Experience</div>
          </div>
        </div>
        <div>
          <button className={classes.swatchShopButton} onClick={() => props.onClick(level)}>
            Apply NOW
          </button>
        </div>
      </div>
    </div>
  );
}
